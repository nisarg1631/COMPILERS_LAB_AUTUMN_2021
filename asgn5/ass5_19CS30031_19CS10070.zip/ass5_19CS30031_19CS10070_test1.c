int main() {
    int n1, n2, n3;
    float f1, f2, f3;
    
    n1 = n2 << 2;
    n2 = n1 >> 2;
    n3 = n1 * n2 / f3;
    f2 = f1 + (-n2 - n3) * f1;
    n1 = n2 ^ n3;
    n2 = (n1 & n2) | n3;
    n3 = n1 & (n2 | n3);
    return 0;
}
